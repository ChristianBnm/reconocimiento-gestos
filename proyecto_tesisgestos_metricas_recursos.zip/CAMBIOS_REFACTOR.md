# Resumen del refactor

## Cambios funcionales

- Se eliminó la dependencia de un número fijo de clases: la capa de salida se crea con el vocabulario activo, y cada checkpoint guarda la lista ordenada y `class_to_idx`.
- Las fuentes y escenarios se trasladaron a `src/core/configuracion/fuentes.json` y `escenarios.json`. Se pueden definir nuevas combinaciones sin ramificar la lógica del pipeline.
- Se separó la semilla de entrenamiento de la semilla de particionado, que se comparte entre arquitecturas para comparar resultados sobre los mismos ejemplos.
- Las particiones se versionan por fingerprint del contenido, semilla y proporciones; versiones previas no se sobrescriben al cambiar el dataset o la semilla.
- Por defecto se conserva una copia por hash exacto y fuente durante la carga, sin borrar archivos. Cada exclusión queda documentada en un CSV junto a la partición. Si se opta por conservar duplicados, estos se agrupan para evitar que atraviesen fronteras de train/validación/test.
- La validación impide contenido idéntico etiquetado con clases diferentes y detecta duplicados exactos entre fuentes ubicados en particiones incompatibles.
- La evaluación produce métricas independientes por fuente, informes por clase, CSV de predicciones y matrices de confusión.
- Los directorios de checkpoint y resultados están separados por escenario y modelo. El entrenamiento exige `--sobrescribir` explícitamente para reemplazar artefactos previos del experimento seleccionado.
- Los scripts auxiliares fueron adaptados al layout nuevo y pueden ejecutarse directamente desde `scripts/`.

## Cambios metodológicos que deben tenerse presentes

- La normalización por defecto ahora resuelve las estadísticas de normalización desde la configuración del checkpoint preentrenado de cada arquitectura.
- El volteo horizontal está desactivado por defecto porque no se ha demostrado que preserve la etiqueta de todas las configuraciones manuales.
- El modo predeterminado sigue siendo extractor de características; el ajuste fino completo se habilita con `--ajuste-fino`.
- La deduplicación exacta en memoria reduce el peso de copias byte a byte repetidas, pero no identifica casi duplicados, secuencias relacionadas ni distintas imágenes de una misma persona.
- La partición actual es por contenido/grupo de duplicado exacto, no por persona o sesión. Por lo tanto, no alcanza para afirmar generalización a personas no vistas.
- Las métricas históricas pertenecen al protocolo anterior y no deben compararse directamente con las nuevas sin reentrenar todos los modelos bajo el mismo protocolo.

## Verificación realizada

- `python -m compileall -q src scripts pruebas`: OK.
- `python -m pytest -q`: 16 pruebas aprobadas.
- Los comandos `--help` del CLI y los scripts auxiliares se ejecutaron correctamente.
- No se ejecutaron entrenamientos reales ni benchmark de las cuatro arquitecturas en esta sesión: el entorno de validación no tiene instalados `timm` ni `albumentations`, y el ZIP de código no incluye los datasets. Antes de lanzar los 12 entrenamientos, ejecutar una prueba pequeña dentro del entorno Docker/GPU del proyecto.
