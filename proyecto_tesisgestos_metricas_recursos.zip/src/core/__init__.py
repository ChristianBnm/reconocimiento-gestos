"""Componentes centrales del proyecto."""
